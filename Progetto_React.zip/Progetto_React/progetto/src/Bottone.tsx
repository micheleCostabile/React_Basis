import React from "react";



//proprietà - props
type testoricevuto = {  //dichiaro le info che voglio ricevere del componente padre
    testo: string,
    citta: string,
    maggiorenne: string
}


export const Bottone = ({ testo: testomio, citta, maggiorenne }: testoricevuto) => {
    let nuovotag:any = "" //è la variabile che conterrà il nuovo tag
    if(maggiorenne.toLowerCase() == "si"){
        nuovotag = <span>Sei maggiorenne</span>
    }
    else{
        nuovotag = <h1>Attenzione verificare l'eta della persona</h1>
    }
    return (
        <div>
            <button>{testomio}</button>
            <label htmlFor="">Sei nato nella città di:{citta}</label>
            {nuovotag}
            <input value={testomio}></input>
        </div>
    )
}