import React, { useState } from 'react';

export const Numeri = () => {
    const [numero, setNumero] = useState<number>(1200)
    const incrementa = () => {
        setNumero(numero + 1);
    }
    const decrementa = () => {
        setNumero(numero - 1);
    }

    return (
        <div>
            <h2>Componente per gestire il decrementa/incrementa</h2>
            <h3>{numero}</h3>
            <div>
                <button onClick={incrementa}>Incrementa</button>
            </div>
            <div>
                <button onClick={decrementa}>Decrementa</button>
            </div>
        </div>
    )
}