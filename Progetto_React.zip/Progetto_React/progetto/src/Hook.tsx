import React, { useState } from 'react';

export const Hook = () => {
    const [nominativo, setNominativo] = useState<string>('Alfredo')
    // nominativo -> nome chiave vecchia
    // setNominativo -> nome del metodo che uso per assegnare valore alla chiave, 
    // useState -> per assegnare un valore di defualt e decidere il tipo
    return <div>
        <h1>Il valore della chiave nominativo è: {nominativo}</h1>
        <label>Inserisci il tuo nome </label>
        <input type="text" value={nominativo} onChange={
            (testoinserito) => {
                setNominativo(testoinserito.target.value);
            }
        }></input>
    </div>
}