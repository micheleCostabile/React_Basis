import React from "react";

import { Passaggio } from "../interfacce/Passaggio";

import { Prelievo } from "./Prelievo";

const orange: any = {
    backgroundColor: 'orange'
}



export const Dirigente:React.FC<Passaggio> = ({aggiornaSaldo,saldo}) => {
    return (
        <div style={orange}>
            <h1>Sono il componente del dirigente</h1>
            <h4>Il saldo attuale è: {saldo}</h4>
            <Prelievo limite={1000}  effettuaPrelievo={aggiornaSaldo}></Prelievo>
        </div>
    )
}