import React from 'react';
import { Prelievo } from './Prelievo';
import { Passaggio } from '../interfacce/Passaggio';

export const Operaio:React.FC<Passaggio> = ({ saldo }, {aggiornaSaldo}) => {

    const verde = {
        backgroundColor: "green"
    }

    return (
        <div style={verde}>
            <h1>Sono il componente dell'operaio</h1>
            <h4>Il saldo attuale è: {saldo}</h4>
            <Prelievo limite={200}  effettuaPrelievo={aggiornaSaldo}></Prelievo>
        </div>
    )   
}
