import React from 'react';
import { Prelievo } from './Prelievo';
import { Passaggio } from '../interfacce/Passaggio';

export const CEO: React.FC<Passaggio> = ({ saldo }, {aggiornaSaldo}) =>{

    const grigio = {
        backgroundColor: "gray"
    }

    
    return (
        <div style={grigio}>
            <h1>Sono il componente del CEO</h1>
            <h4>Il saldo attuale è: {saldo}</h4>
            <Prelievo limite={saldo}  effettuaPrelievo={aggiornaSaldo}></Prelievo>
        </div>
    )
}