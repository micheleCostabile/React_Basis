import React, { useEffect, useState } from 'react';
import { GestioneVersamento } from '../interfacce/GestioneVersamento';

export const Versamento: React.FC<GestioneVersamento> = ({ aggiornaIlPadre }, {saldoAttuale}) => {

    const giallo = {
        backgroundColor: "yellow"
    }

    const [importo, setImporto] = useState<number>(0)
    useEffect(() => {
        console.log("Hai variato l'importo:" + importo)
    }, [importo]
    )
    return (
        <div style={giallo}>
            <h2>Componente per versare</h2>
            <label htmlFor="">Importo da versare: </label>
            <input type="number" onChange={
                (valore) => setImporto(parseInt(valore.target.value)?parseInt(valore.target.value):0)
            } />
            <br /><br />
            <span>Stai per versare {importo ? importo : 0}</span>
            <br /><br />
            <button onClick={
                () => {
                    aggiornaIlPadre(importo)
                    setImporto(0)
                }
            }>Conferma versamento</button>
            <br /><br />
            <label>Saldo attuale: {saldoAttuale}</label>
            <br /><br />
        </div>
    )
}