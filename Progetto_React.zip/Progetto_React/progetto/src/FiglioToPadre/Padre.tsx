import React, { useState } from 'react';
import { Versamento } from './Versamento';
import { CEO } from './CEO';
import { Operaio } from './Operaio';
import { Dirigente } from './Dirigente';

export const Padre = () => {
    const [saldo, setSaldo] = useState<number>(500)

    const celeste: any = {
        backgroundColor: "aqua"
    }
    const aggiungiImporto = (importoRicevuto: number): void => {
        setSaldo(saldo + importoRicevuto)
    }
    const prelevaImporto = (importoRicevuto: number): void => {
        if (importoRicevuto > saldo) {
            alert("Fondi non disponibili")
        }
        else {
            setSaldo(saldo - importoRicevuto)
        }
    }
    return (
        <div style={celeste}>
            <h1>ATM</h1>
            <h3>Il saldo della carta è: {saldo}</h3>
            <br /><br />
            <Versamento aggiornaIlPadre={aggiungiImporto} saldoAttuale={saldo}></Versamento>
            <br /><br />
            <CEO saldo={saldo} aggiornaSaldo={prelevaImporto}></CEO>
            <br /><br />
            <Dirigente saldo={saldo} aggiornaSaldo={prelevaImporto}></Dirigente>
            <br /><br />
            <Operaio saldo={saldo} aggiornaSaldo={prelevaImporto}></Operaio>
            <br /><br />
        </div>
    )
}