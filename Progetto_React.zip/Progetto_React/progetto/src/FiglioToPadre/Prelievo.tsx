import React, { useState } from "react";
import { GestionePrelievo } from "../interfacce/GestionePrelievo";
const rosso: any = {
    backgroundColor: 'red'
}

export const Prelievo: React.FC<GestionePrelievo> = ({ limite, effettuaPrelievo }) => {

    const [importo, setImporto] = useState<number>(0);

    return (
        <div style={rosso}>
            <h5>Componente per prelevare</h5>
            <label htmlFor="">Importo da prelevare</label>
            <input
                type="text"
                value={importo}
                onChange={
                    (valore) => {
                        setImporto(parseInt(valore.target.value)?parseInt(valore.target.value):0);
                    }
                }
            />
            <span>Stai per prelevare {importo ? importo : 0}</span>
            <button
                onClick={
                    () => {
                        if (importo > limite) {
                            alert("Non puoi superare il limite di:" + limite);
                        }
                        else {
                            effettuaPrelievo(importo);
                            setImporto(0)
                        }
                    }
                }
            >Conferma prelievo</button>
        </div>
    )
}