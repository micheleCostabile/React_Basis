import React, { useState } from "react";
import { ITreno } from "./interfacce/ITreno";
import { SingoloViaggio } from "./SingoloViaggio";

export const Stazione = () => {
    let viaggi: Array<ITreno> = [ //inizializza l'hook dei viaggi
        { partenza: "Como", arrivo: "Pordenone", chilometri: 300, id: 0 },
        { partenza: "Pescara", arrivo: "Bologna", chilometri: 250, id: 1 },
        { partenza: "La Spezia", arrivo: "Parma", chilometri: 450, id: 2 },
    ]

    const [treni, setTreni] = useState<Array<ITreno>>(viaggi);
    const [partenza, setPartenza] = useState<string>("");
    const [arrivo, setArrivo] = useState<string>("")
    const [chilometri, setChilometri] = useState<number>(0)

    const inserisciTreno = () => {
        let treno: ITreno = {
            partenza: partenza,
            arrivo: arrivo,
            chilometri: chilometri,
            id: treni.length
        }
        setTreni([...treni, treno])
    }
    return (
        <div>
            <h1>Componente per la gestione degli array</h1>
            <div>
                <label htmlFor="">Stazione di partenza</label>
                <input type="text" value={partenza} onChange={
                    (partenza) => {
                        setPartenza(partenza.target.value)
                    }
                }></input>
                <label htmlFor="">Stazione di arrivo</label>
                <input type="text" value={arrivo} onChange={
                    (arrivo) => {
                        setArrivo(arrivo.target.value)
                    }
                }></input>
                <label htmlFor="">Chilometri</label>
                <input type="number" value={chilometri} onChange={
                    (chilometri) => {
                        setChilometri(parseInt(chilometri.target.value))
                    }
                }></input>
                <button onClick={inserisciTreno}>Aggiungi Viaggio</button>
            </div>
            <label>{partenza} -  {arrivo} - {chilometri}</label>
            <div>
                <table>
                    <thead>
                        <tr>
                            <td>Partenza</td>
                            <td>Arrivo</td>
                            <td>Chilometri</td>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            treni.map(
                                (treno) => {
                                    return <tr key={treno.id}>
                                        <td>{treno.partenza}</td>
                                        <td>{treno.arrivo}</td>
                                        <td>{treno.chilometri}</td>
                                    </tr>
                                }
                            )
                        }

                    </tbody>
                </table>
            </div>
            <br /><br />
            <table>
                <tbody>{
                    treni.map(
                        (treno) => {
                            return <SingoloViaggio key={treno.id} viaggioRicevuto={treno}></SingoloViaggio>
                        })
                }
                </tbody></table>
        </div>
    )
}