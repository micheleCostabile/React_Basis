import React, { Component } from "react";

class Maschera extends Component {
    state: any = {
        nominativo: "",
        cognome: "",
        anni: 0
    }

    cambiaNome(oggettoRicevuto: any) {
        this.setState({
            nominativo: oggettoRicevuto.target.value
        })
    }

    cambiaCognome(oggettoRicevuto: any) {
        this.setState({
            cognome: oggettoRicevuto.target.value
        })
    }

    addAnni(anniRicevuti:any) {
        this.setState({
            anni: parseInt(anniRicevuti.target.value) + this.state.anni
        })
    }

    invia(formRicevuta: any) {
        alert(this.state.nominativo + " - " + this.state.cognome + " - " + this.state.anni)
        formRicevuta.preventDefault()
    }

    render() {
        return <div>
            <h1>Ciao sono un component class (stateful)</h1>
            <form action="" onSubmit={this.invia.bind(this)}>
                <label htmlFor="">Nome </label>
                <input type="text" value={this.state.nominativo} onChange={this.cambiaNome.bind(this)}></input>
                <br></br>
                <span>Il nome digitato è: {this.state.nominativo}</span>
                <br></br><br></br>
                <label htmlFor="">Cognome </label>
                <input type="text" value={this.state.cognome} onChange={this.cambiaCognome.bind(this)}></input>
                <br></br>
                <span>Il cognome digitato è: {this.state.cognome}</span>
                <br></br><br></br>
                <label htmlFor="">Aggiungi anni </label>
                <input type="number" value={this.state.anni} onChange={this.addAnni.bind(this)}></input>
                <br></br>
                <span>Gli anni digitati sono: {this.state.anni}</span>
                <br></br><br></br>
                <button type="submit">Conferma Dati</button>
            </form>
        </div>

    }
}

export { Maschera }