import React from "react";

const FunzioneAnonima = function () {
    return <h1>Sono un componente creato mediante una funzione anonima </h1>
}

export default FunzioneAnonima;