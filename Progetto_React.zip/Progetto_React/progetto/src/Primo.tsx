import React from "react";

function Primo() {
    return (
        <div>
            <label htmlFor="">Un saluto dal primo componente React</label>
            <div>
                Componente semplice, detto functional component (stateless)
            </div>
            <Test></Test>
        </div>
    )
}

function Test() {
    return (
        <label htmlFor="">Funzione Test inserita dentro primo.tsx</label>
    )
}


export default Primo;