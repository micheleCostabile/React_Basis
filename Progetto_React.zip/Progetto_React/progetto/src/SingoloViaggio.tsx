import React, { useState } from 'react';
import { ITreno } from './interfacce/ITreno';

type ricevuto = {
    viaggioRicevuto: ITreno
}
export const SingoloViaggio = ({ viaggioRicevuto }: ricevuto) => {
    const [visualizza, setVisualizza] = useState<Boolean>(false)
    let listaOggetti: any = ""

    if (visualizza) {
        listaOggetti = (<div><td>{viaggioRicevuto.partenza}</td>
            <td>{viaggioRicevuto.arrivo}</td>
            <td>{viaggioRicevuto.chilometri}</td></div>)
    }
    return (
        <tr>
            <td>{viaggioRicevuto.id}</td>
            {listaOggetti}
            <td>
                <button onClick={
                    () => {
                        visualizza?setVisualizza(false):setVisualizza(true)
                    }
                }
                >{visualizza?"Nascondi":"Vedi"} dettaglio</button>
            </td>
        </tr>
    )
}