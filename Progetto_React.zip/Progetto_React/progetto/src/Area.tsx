import React, { useState } from 'react';

export const Area = () => {
    const [base, setBase] = useState<number>(0)
    const [altezza, setAltezza] = useState<number>(0)
    const [tipo, setTipo] = useState<string>("1")
    const [calcolo, setCalcolo] = useState<number>(0)
    const divisori: Array<any> = [
        {divisore:"1", voce:"Rettangolo"},
        {divisore:"2", voce:"Triangolo"},
        {divisore:"5", voce:"Pentagono"}
    ]

    return <div>
        <table>
            <tr>
                <td><label>Base</label></td>
                <td><input type="number" value={base} onChange={
                    (valore) => {
                        setBase(parseInt(valore.target.value))
                    }
                }></input>
                    <span>Digitato: {base}</span></td>
            </tr>
            <tr>
                <td><label>Altezza</label></td>
                <td><input type="number" value={altezza} onChange={
                    (valore) => {
                        setAltezza(parseInt(valore.target.value))
                    }}></input>
                    <span>Digitato: {altezza}</span></td>
            </tr>
            <tr>
                <td><label>Figura</label></td>
                <td>
                    <select value={tipo} onChange={
                        (valore)=>{
                            setTipo(valore.target.value)
                        }
                    }>
                        {/* <option value="1">Rettangolo</option>
                            <option value="2">Triangolo</option> */}
                        {
                            divisori.map((nomeFigura,indice) =>{
                                return <option key={indice} value={nomeFigura.divisore}>{nomeFigura.voce}</option>
                            })
                        }
                    </select>
                    <span>Divisore: {tipo}</span>
                </td>
            </tr>
            <tr>
                <td><button onClick={
                    () => {
                        let areaCalcolata = (base * altezza) / parseInt(tipo)
                        setCalcolo(areaCalcolata)
                    }}>Calcola area</button></td>
                <td><span>Area calcolata: {calcolo}</span></td>
            </tr>
        </table>
    </div>

}