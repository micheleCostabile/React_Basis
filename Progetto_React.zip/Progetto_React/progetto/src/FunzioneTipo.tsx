import React from "react";

export const FunzioneTipo = () => {
    return (
        <h1>Componente con funzione a freccia senza il default</h1>
    )
}
export const Tipo = () => {
    return (
        <h3>Componente esportato da un file composto da più esportazioni</h3>
    )
}