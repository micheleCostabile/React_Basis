import React from "react";
import { Bottone } from "./Bottone";

export const Freccia = () => {
    return <div>
        <h2>Componente creato con una funzione a freccia</h2>
        <Bottone testo="Prova" citta="Naboli" maggiorenne="no"></Bottone>
    </div>
}

export default Freccia