export interface Passaggio{
    saldo: number,
    aggiornaSaldo: (valore:number) => void
}