export interface GestioneVersamento {
    aggiornaIlPadre: (valore: number) => void,
    saldoAttuale: number;
}