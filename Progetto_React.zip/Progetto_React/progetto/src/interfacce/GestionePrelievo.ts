export interface GestionePrelievo {
    limite: number,
    effettuaPrelievo: (importo: number) => void
}