export interface ITreno {
    partenza: string,
    arrivo: string,
    chilometri: number,
    id: number
}