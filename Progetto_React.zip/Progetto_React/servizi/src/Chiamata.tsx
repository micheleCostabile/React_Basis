import React, { useState } from "react";
import axios from "axios";
import { IUser } from "./interfacce/IUser";
import { IPost } from "./interfacce/IPost";

export const Chiamata = () => {
    const rosso = {
        backgroundColor: "red"
    }
    const giallo = {
        backgroundColor: "yellow"
    }
    const celeste = {
        backgroundColor: "aqua"
    }
    const [users, setRicevuti] = useState<Array<IUser>>([])
    const [post, setPost] = useState<IPost>()
    function callServiceGET() {
        axios.get<Array<IUser>>("https://jsonplaceholder.typicode.com/users")
            .then((risposta) => {
                setRicevuti(risposta.data)
            }
            )
            .catch((errore) => {
                alert(errore)
            })
    }

    function callServicePOST(){
        let post:IPost = {
            userId: 1,
            id: 500,
            title: "Carmine",
            body: "è molto bello"
        }
        axios.post<IPost>("https://jsonplaceholder.typicode.com/posts",post)
        .then(
            (risposta) => {
                alert("è molto bello")
            }
        )
        .catch(
            (errore) => {
                alert(errore)
            }
        )
    }


    return (
        <div style={rosso}>
            <h1>Componente per chiamare i servizi</h1>
            <br /><br />
            <button onClick={callServiceGET}>Chiamata get per gli utenti</button>
            <br /><br />
            <div style={giallo}>
            <table>
                <thead>
                    <tr>
                        <th>name</th>
                        <th>username</th>
                        <th>email</th>
                        <th>address</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map(
                            (user) => {
                                return (
                                    <tr key={user.id}>
                                        <td>{user.name}</td>
                                        <td>{user.username}</td>
                                        <td>{user.email}</td>
                                        <td>{user.address.suite} {user.address.city} {user.address.street} {user.address.zipcode}</td>
                                    </tr>
                                )
                            })
                    }
                </tbody>
            </table>
            </div>
            <div style={celeste}>
                <h3>Chiamata post</h3>
            <button onClick={callServicePOST}>Inserisci annuncio</button>
            </div>
        </div>
    )
}