import React, { useEffect, useState } from "react";
import axios from "axios";
import { IUser } from "./interfacce/IUser";
import { IPost } from "./interfacce/IPost";

export const ChiamataDueGet = () => {
    const [users, setUsers] = useState<Array<IUser>>([])
    const [posts, setPosts] = useState<Array<IPost>>([])
    const [caricato, setCaricato] = useState<boolean>(false)

    const yellow = {
        backgroundColor: "yellow"
    }
    const aqua = {
        backgroundColor: "aqua"
    }

    function callServiceGETUsers() {
        axios.get<Array<IUser>>("https://jsonplaceholder.typicode.com/users")
            .then((risposta) => {
                setUsers(risposta.data)
            }
            )
            .catch((errore) => {
                alert(errore)
            })
    }

    function callServiceGETPosts(userId: number) {
        let url = "https://jsonplaceholder.typicode.com/posts?userId=" + userId
        axios.get<Array<IPost>>(url)
            .then((risposta) => {
                setPosts(risposta.data)
                setCaricato(true)
            }
            )
            .catch((errore) => {
                alert(errore)
            })
    }

    useEffect (() => {
        if (!caricato) {
            callServiceGETUsers()
        }
    })

    return (
        <div style={yellow}>
            <select onChange={valore => callServiceGETPosts(parseInt(valore.target.value))}>
                {
                    users.map(
                        (user) => {
                            return (<option key={user.id} value={user.id}>{user.name} - {user.email}</option>)
                        }
                    )
                }
            </select>
            <br /><br />
            <div style={aqua}>
                <table>
                    <thead>
                        <tr>
                            <th>UserId</th>
                            <th>id</th>
                            <th>Title</th>
                            <th>Body</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            posts.map((post) => {
                                return (
                                    <tr key={post.id}>
                                        <td>{post.userId}</td>
                                        <td>{post.id}</td>
                                        <td>{post.title}</td>
                                        <td>{post.body}</td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
        </div >
    )
}