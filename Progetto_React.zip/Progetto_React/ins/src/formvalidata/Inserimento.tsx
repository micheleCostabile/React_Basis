import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as Yup from 'yup'

type OggettoForm = {
    nome: string,
    cognome: string,
    anni: number
}
export const Inserimento = () => {

    //oggetto per gestire la validità dei dati
    const validazione = Yup.object().shape(
        {
            nome: Yup.string().required('Il campo nome è obbligatorio'),
            cognome: Yup.string().required('Il cognome è obbligatorio').min(5, 'Inserire almeno 5 caratteri'),
            anni: Yup.number().min(18, 'Devi essere maggiorenne per registrarti')
        }
    )


    //destrutturazione dei metodi di useForm
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm<OggettoForm>
            (
                { resolver: yupResolver(validazione) }
            )


    //metodo che gestisce la conferma dei dati
    const sottoMetti = (datiInseriti: OggettoForm) => {
        console.log(datiInseriti);
    }

    return (
        <div>
            <h1>Pagina di inserimento dati</h1>
            <div className="register-form">
                <form onSubmit={handleSubmit(sottoMetti)}>

                    <div className="form-group">
                        <label htmlFor="">Inserisci il tuo nome</label>
                        <input
                            type="text"
                            {...register('nome')}
                            className={`form-control ${errors.nome ? 'is-invalid' : ''}`}
                        />
{/*                         <div className='invalid-feedback'>{errors.nome?.message}</div>
 */}                    </div>

                    <div className="form-group">
                        <label htmlFor="">Inserisci il tuo cognome</label>
                        <input
                            type="text"
                            {...register('cognome')}
                            className={`form-control ${errors.cognome ? 'is-invalid' : ''}`}

                        />
{/*                         <div className='invalid-feedback'>{errors.cognome?.message}</div>
 */}                    </div>

                    <div className="form-group">
                        <label htmlFor="">Inserisci i tuoi anni</label>
                        <input
                            type="number"
                            {...register('anni')}
                            className={`form-control ${errors.anni ? 'is-invalid' : ''}`}
                        />
                        <div className='invalid-feedback'>{errors.anni?.message}</div>
                    </div>

                    <div className="form-group">
                        <button type="submit" className="btn btn-primary">Conferma dati</button>
                        <button onClick={
                            () => {
                                reset();
                            }
                        } className="btn btn-warning"
                        >Pulisci campi</button>
                    </div>
                </form>
            </div>
        </div>
    )
}